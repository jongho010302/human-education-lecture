// vue 및 확장 모듈 import
import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import './registerServiceWorker'
import vuetify from './plugins/vuetify';
import VueTimeago from 'vue-timeago';
import axios from 'axios';

// Vue앱의 $http라는 변수에 axios 객체를 등록
Vue.prototype.$http = axios;

// 앱 및 추가기능 설정
Vue.config.productionTip = false
Vue.use(VueTimeago,{
  name: 'Timeago', // Component name, `Timeago` by default
  locale: 'en' // Default locale
})

// Vue 인스턴스 생성
new Vue({
  router,
  store,
  vuetify,
  render: h => h(App)
}).$mount('#app')
