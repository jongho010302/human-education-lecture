<template>
  <v-card class="mt-5">
    <!-- 프로필 -->
    <v-list-item>
      <!-- 프로필 이미지 -->
      <v-list-item-avatar color="grey">
        <v-img :src="feed.profileImg" alt="avatar"></v-img>    
      </v-list-item-avatar>
      <!-- 프로필 이름 -->
      <v-list-item-content>
        <v-list-item-title class="headline">{{feed.profileShort}}</v-list-item-title>
        <v-list-item-subtitle>{{feed.profileName}}</v-list-item-subtitle>
      </v-list-item-content>
      <!-- 메뉴 -->
      <v-menu bottom left offset-y>
        <template v-slot:activator="{ on }">
          <v-btn icon v-on="on"><v-icon>mdi-dots-vertical</v-icon></v-btn>
        </template>
        <v-list>
          <v-list-item><v-btn text @click="del()">Remove</v-btn></v-list-item>
          <v-list-item><v-btn text @click="edit()">Edit</v-btn></v-list-item>
        </v-list>
      </v-menu>      
    </v-list-item>
    <!-- 시간 -->
    <v-card-text class="mb-0 pb-0">
      <v-icon small class="mr-1">mdi-clock-outline</v-icon>
      <timeago :datetime="feed.timestamp" :auto-update="60" :converterOptions="{includeSeconds:true}"></timeago >
    </v-card-text> 
    <!-- 타이틀 -->
    <v-card-Title class="mt-0 pt-0">
      <div style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
        {{feed.content}}
      </div>
    </v-card-Title>
    <!-- 컨텐트 -->
    <v-card-text color="primary">
      <div>{{feed.content}}</div>
      <div v-if="feed.attachedImg"><v-img :src="feed.attachedImg"></v-img></div>
      <div v-if="feed.attachedVid">
        <video :key="index + 'vid'" controls  style="width: 100% !important; height:auto !important;" :src="feed.attachedVid"></video>             
      </div>
    </v-card-text> 
    <!-- 액션 -->
    <v-card-actions>
      <v-btn text color="deep-purple accent-4">
        <v-icon small>mdi-heart-circle</v-icon>like
      </v-btn>
      <v-btn text color="deep-purple accent-4">
        <v-icon small>mdi-chat</v-icon>comment
      </v-btn>
      <v-btn text color="deep-purple accent-4">
        <v-icon small>mdi-share</v-icon>share
      </v-btn>                  
    </v-card-actions>
  </v-card>
</template>
<script>
export default {
  name: "feed-item",
  // props 정의
  props: ["feed", "index"],
  methods: {
    del(){
      // FeedItem 컴퍼넌트가 선언되어 있는 곳의 @del(v-on:del) 이벤트를 작동시킴
      // 매개변수로 부모로부터 받은 "index" prop을 전달
      this.$emit("del", this.index);
    },
    edit(){
      this.$emit("edit", this.index);
    }
  }
}
</script>