import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    isLogin:false,
    kakaoAccessToken:"",
    profile:{}
  },
  mutations: {
    login: function (state) {
      state.isLogin = true;
    },
    accessToken: function (state, payload){
      state.kakaoAccessToken = payload;
    },
    profile: function(state, payload){
      state.profile.id = payload.id;
      state.profile.accountEmail = payload.kakao_account.email;
      state.profile.nickname = payload.properties.nickname;
      state.profile.thumbnail = payload.properties.thumbnail_image;
    }
  },
  actions: {

  }
})
