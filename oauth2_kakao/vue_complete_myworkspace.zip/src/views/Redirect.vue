<template>
  <div></div>
</template>
<script>
export default {
  
  methods:{
      getParameterByName(name) {
          var match = RegExp('[?&]' + name + '=([^&]*)').exec(window.location.search);
          return match && decodeURIComponent(match[1].replace(/\+/g, ' '));
      }    
  },
  created(){
    var code = this.getParameterByName("code");
    var data = "grant_type=authorization_code" +
                "&client_id=" + "83adca921c699cc375407a61a4e90342" +
                "&redirect_uri=" + "http://localhost:8080/redirect" +
                "&code=" + code;

    this.$http.post("https://kauth.kakao.com/oauth/token", data).then(result=>{
      console.log(result.data);
      console.log(result.data.access_token);
      this.$store.commit("accessToken", result.data.access_token);
      
      var config = {
          headers: {'token': result.data.access_token}
      };
      this.$http.get("http://localhost:9091/profile", config).then(result=>{
        //console.log(result);
        this.$store.commit("login");
        this.$store.commit("profile", result.data);
        this.$router.push("/");
      });
    });
  }
}
</script>