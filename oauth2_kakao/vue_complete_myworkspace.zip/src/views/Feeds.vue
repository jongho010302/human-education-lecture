<template>
<div>
  <v-container>
    <v-row>
      <!-- default cols 12, md or higher 3 -->
      <v-col cols="12" md="3">
        <v-card>
          <!-- 프로필 -->
          <v-list-item>
            <!-- 프로필 이미지 -->
            <v-list-item-avatar color="grey" class="my-0 ml-0 mr-2">
              <v-img :src="$store.state.profile.thumbnail" alt="avatar" ></v-img>    
            </v-list-item-avatar>
            <!-- 프로필 이름 -->
            <v-list-item-content>
              <v-list-item-title class="headline">@{{$store.state.profile.nickname}}</v-list-item-title>
              <v-list-item-subtitle>{{$store.state.profile.accountEmail}}</v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>          
          <v-list-item>
            <v-list-item-content>
              <p>
                Developer of web applications, JavaScript, PHP, Java, Python, C#, Java, Node.js, etc.
              </p>
            </v-list-item-content>              
          </v-list-item>
          <v-divider></v-divider>
          <!-- 팔로워 팔로잉 -->
          <v-list-item two-line>
            <v-list-item-content>
              <v-list-item-title>Followers</v-list-item-title>
              <v-list-item-subtitle>5.2342</v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>
          <v-divider></v-divider>
          <v-list-item two-line>
            <v-list-item-content>
              <v-list-item-title>Following</v-list-item-title>
              <v-list-item-subtitle>6758</v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>                                  
        </v-card>
      </v-col>

      <v-col cols="12" md="6">
        <v-card>
          <v-tabs color="deep-purple accent-4">
            <v-tab @click="isImage = false; isVideo = false;">Make a publiication</v-tab>
            <v-tab @click="isImage = true; isVideo = false;">Images</v-tab>
            <v-tab @click="isImage = false; isVideo = true;">Videos</v-tab>          
          </v-tabs>
          <div class="pa-3">
            <v-textarea label="What are you thinking?" class="ma-0 pa-0" v-model="post"></v-textarea> 
            <v-file-input v-if="isImage" class="ma-0 pa-0"
              accept="image/png, image/jpeg, image/bmp"
              prepend-icon="mdi-camera" label="pick a photo" 
              v-model="file"></v-file-input>
            <v-file-input v-if="isVideo" class="ma-0 pa-0"
              accept="video/mp4"
              prepend-icon="mdi-camera" label="pick a video" 
              v-model="file"></v-file-input>                                                          
            <v-btn small dark color="deep-purple accent-4" @click="share()" >Share</v-btn>
          </div>
        </v-card>
        <!--자식으로부터 del이벤트를 emit 받으면 delFeed 메소드 실행-->
        <!--delFeed 메소드의 첫번째 매개변수는 자식으로부터 받은 매개변수-->
        <feed-item @del="delFeed" @edit="setEdit" :feed="feed" :index="index" v-for="(feed, index) in feeds" :key="index"></feed-item>
        <!-- 피드 수정용 다이얼로그-->
        <v-dialog v-if="isEdit" v-model="isEdit" persistent max-width="600px">
          <v-card>
            <!-- 프로필 -->
            <v-list-item>
              <!-- 프로필 이미지 -->
              <v-list-item-avatar color="grey">
                <v-img :src="feed.profileImg" alt="avatar"></v-img>    
              </v-list-item-avatar>
              <!-- 프로필 이름 -->
              <v-list-item-content>
                <v-list-item-title class="headline">{{feed.profileShort}}</v-list-item-title>
                <v-list-item-subtitle>{{feed.profileName}}</v-list-item-subtitle>
              </v-list-item-content>      
            </v-list-item>
            <!-- 컨텐트 -->
            <v-card-text color="primary">
              <v-textarea class="ma-0 pa-0" v-model="feed.content"></v-textarea>                                  
            </v-card-text> 
            <v-card-actions>
              <div class="flex-grow-1"></div>
              <v-btn color="blue darken-1" text @click="isEdit = false">Close</v-btn>
              <v-btn color="blue darken-1" text @click="modifyFeed()">Save</v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>        
      </v-col>

      <v-col cols="12" md="3">
        <v-card class="mb-10" >
          <v-card-text>
            <div>Word of the Day</div>
            <p class="display-1 text--primary">
              be•nev•o•lent
            </p>
            <p>adjective</p>
            <div class="text--primary">
              well meaning and kindly.<br>
              "a benevolent smile"
            </div>
          </v-card-text>
          <v-card-actions>
            <v-btn text color="deep-purple accent-4" >
              Learn More
            </v-btn>
          </v-card-actions>
        </v-card>
        <v-card >
          <v-card-text>
            <div>Word of the Day</div>
            <p class="display-1 text--primary">
              be•nev•o•lent
            </p>
            <p>adjective</p>
            <div class="text--primary">
              well meaning and kindly.<br>
              "a benevolent smile"
            </div>
          </v-card-text>
          <v-card-actions>
            <v-btn text color="deep-purple accent-4" >
              Learn More
            </v-btn>
          </v-card-actions>
        </v-card>        
      </v-col>            
    </v-row>
  </v-container>
</div>
</template>

<script>
  import FeedItem from '@/components/FeedItem';
  export default {
     components: {
      FeedItem,
    },
    data: () => ({
      dataURL: "http://localhost:9090/feeds",
      isImage:false,  // 이미지 포스트 여부
      isVideo:false,  // 비디오 포스트 여부
      post: "", 
      file: null,                             
      feeds:null,
      isEdit: false,
      feed:null,
      editIndex: null
    }),
    methods: {
      share(){
        var base64File = "";
        console.log(this.file)
        if(this.file){
          // 파일이 있으면base64로 변환
          var reader = new FileReader();
          reader.readAsDataURL(this.file);
          reader.onload = () =>{
            base64File = reader.result;
            //console.log(base64File);
            this.addFeed(base64File);
          };
          reader.onerror = (error) =>{
            console.log('Error: ', error);
          }; 
        } else {
          this.addFeed();
        }
      },
      addFeed(fileString){
        // 데이터로 전송할 객체
        const feed = {
          profileImg:this.$store.state.profile.thumbnail,
          profileShort:this.$store.state.profile.nickname,
          profileName:this.$store.state.profile.accountEmail,
          timestamp: new Date().getTime(),
          content: this.post,
          attachedImg: this.isImage ? fileString : null,
          attachedVid: this.isVideo ? fileString : null
        };

        // 데이터 전송
        this.$http.post(this.dataURL, feed).then((result)=>{
          console.log(result.data);
          // 저장후 응답 받은 데이터의 id롤 설정
          feed.id = result.data.id;

          // 피드 추가
          this.feeds.unshift(feed);

          // 입력박스 및 파일 초기화
          this.post = "";  
          this.file = null;
        });

      },
      delFeed(index){
        // 데이터 삭제
        // `http://localhost:9090/feeds/1`
        this.$http.delete(`${this.dataURL}/${this.feeds[index].id}`).then(()=>{        
          this.feeds.splice(index, 1);
        });
      },
      setEdit(index){
        this.feed = JSON.parse(JSON.stringify(this.feeds[index]));
        this.editIndex = index;
        this.isEdit = true;
      },
      modifyFeed(){
        this.$http.put(this.dataURL, {id:this.feed.id, content:this.feed.content}).then(()=>{
          // 피드배열에서 수정한 데이터로 변경
          this.feeds[this.editIndex] = this.feed;
          this.isEdit = false;
        });        
      },
    },
    // vue 생성시에 호출되는 함수
    created() {
      this.feeds = [];
    },
    mounted(){
      if(!this.$store.state.isLogin){
        this.$router.push("/login");
        return;
      } 

      // axios로 get 호출
      // 호출이 완료되면 .then 내부에 있는 메소드가 호출됨
      this.$http.get(this.dataURL).then((result)=>{
        console.log(result);
        // 결과 데이터를 배열로
        this.feeds = result.data;

        // 피드 파일 조회
        this.feeds.forEach(feed => {
          this.$http.get(`${this.dataURL}/feed-file/${feed.id}`).then((result) => {

            // 배열 내부의 객체에 속성을 바로 설정하면 화면에 적용되지 않으므로 Vue.set 메소드를 이용하여 속성에 값을 설정한다.
            this.$set(feed, "attachedImg", result.data.attachedImg);
            this.$set(feed, "attachedVid", result.data.attachedVid);
          });
        });        
      });      
    }    
  }
</script>