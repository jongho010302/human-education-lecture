<template>
  <div>
    <v-container>
      <v-row>
        <!-- default cols 12, md or higher 6 -->
        <v-col cols="12" md="6">
        <!-- 왼쪽 ToDo List -->
        <v-card>
          <!-- ToDo List 타이틀 -->
          <h1 class="card-title text-center font-italic">ToDo List</h1> 
            <!-- Add todo 빈칸 -->
            <v-textarea class="mx-2" label="Add todo" color="blue-grey lighten-4" auto-grow outlined rows="1" row-height="15" v-model="memo"></v-textarea>
            <!-- 빈칸으로 SHOW 버튼 클릭 시 나타나는 화면 -->
            <div class="mx-2 ml-3" label="Add todo" v-if="blank">-- Please enter text --</div>
            <!-- 버튼,버튼 아이템 -->
            <v-card-actions>
            <v-btn class="ml-1" color="indigo darken-1"  @click="add()" text>Add</v-btn>
            <v-btn color="deep-purple darken-1" @click="doneAll()" text>Mark all as done</v-btn>
            </v-card-actions>
          <!-- 왼쪽 ToDo List 목록 -->
          <v-card-text>
          <!-- 왼쪽 ToDo List 하단에 텍스트를 추가 할 수 있는 아이템 -->
            <div class="list-group-item" v-for="(todo, index) in todoList" :key="index">
              <label>
                <!-- 왼쪽 checkbox 아이콘 -->
                <v-icon color="warning" dark @click="done(todo,index)">mdi-emoticon-kiss</v-icon>
                <!-- 오늘의 할일 텍스트 작성 -->
                <span class="ml-3">{{todo.memo}}</span>
              </label>
            </div>
          </v-card-text> 
        </v-card>
      </v-col>
        <!-- default cols 12, md or higher 3 -->
        <v-col cols="12" md="6">
         <!-- 오른쪽 Already Done (완료목록) --> 
         <v-card>
          <!-- Already Done 타이틀 -->
          <h1 class="card-title text-center font-italic">Already Done</h1>
          <v-card-text>
            <!-- Already Done (완료목록) 으로 텍스트 보내기 -->
            <div class="list-group list-group-flush" v-for="(done, index) in doneList" :key="index">
              <label>
                <!-- 완료한 오늘의 할일 텍스트 보이게 하는 코드 -->
                <span class="mr-2" style="text-decoration: line-through;">{{done.memo}}</span>
                <!-- 오른쪽 checkbox 아이콘 -->
                <v-icon color="dark" @click="remove(index)">mdi-emoticon-kiss-outline</v-icon>
              </label>
            </div>
          </v-card-text> 
         </v-card>
        </v-col>
      </v-row>
    </v-container>
  </div>  
</template>

<!-- ToDo List 버튼 이벤트 -->
<script>
export default {
  data() {
    return {
      dataURL: "http://localhost:9090/todo",
      memo:"", // 입력 테스트 변수 -input에 v-model로 연결
      isError: false,
      todoList:null, // todo list 배열 - li에 v-for로 연결
      doneList:null,
      blank: false // blank : 빈칸에 SHOW 클릭 시 보이는 텍스트의 v-if 요소 이름(?)
    }
  }
  ,
  methods: {
    add(){
      if(this.memo == "") {
        this.blank = true;
        return;
      }
      this.blank = false;

      this.$http.post(this.dataURL, {memo:this.memo})
      .then((result)=>{
        console.log(result);
        this.todoList.unshift(result.data);
        this.memo = ""; //입력박스 초기화
      });
    },
    done: function(todo,index){
      this.$http.put(this.dataURL, {id:todo.id, done:true})
      .then((result)=>{
        console.log(result);
        this.doneList.unshift(todo); // doneList 배열 앞에 선택한 객체 추가
        this.todoList.splice(index,1); // todoList 배열에 해당 인덱스 개채 삭제
      });
    },
    doneAll:function(){
      // 모든 항목의 완료 필드를 true로 변경
      this.todoList.forEach((todo)=>{
        todo.done = true;
      });
      this.$http.put(this.dataURL+"/save-all", this.todoList).then((result)=>{
        console.log(result.data);

        this.doneList = this.todoList.concat(this.doneList); // todoList와 doneList 결합
        this.todoList = []; //todoList 초기화
      }); 
    },
    remove:function(index){
      console.log(this.doneList[index]);
      this.$http.delete(`${this.dataURL}/${this.doneList[index].id}`)
      .then(()=>{
        this.doneList.splice(index, 1); // todoList 하단에 작성한 텍스트 오른쪽 Already Done으로 보내고 삭제
      });
    }
  },
  created(){
    this.todoList = [];
    this.doneList = [];
    
    this.$http.get(this.dataURL).then((result)=>{
      console.log(result.data);
      // isDone이 false인 목록
      this.todoList = result.data.filter(function(item){
        return !item.done;
      });

      // isDone true인 목록
      this.doneList = result.data.filter(function(item){
        return item.done;
      });      
    });    
  }
}
</script>