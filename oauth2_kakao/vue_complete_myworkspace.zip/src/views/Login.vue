<template>
  <v-container>
    <v-row>
      <v-col cols="12" md="4">
      </v-col>
      <!-- default cols 12, md or higher 3 -->
      <v-col cols="12" md="4" style="text-align:center;">
        <img style="margin:0 auto; cursor:pointer;" @click="login()" src="https://developers.kakao.com/assets/img/about/logos/kakaologin/kr/kakao_account_login_btn_medium_narrow.png" />
      </v-col>
      <v-col cols="12" md="4">
      </v-col>      
    </v-row>
  </v-container>
</template>
<script>
export default {
  
  methods:{
    login(){
      var url = "https://kauth.kakao.com/oauth/authorize"
                                  +"?client_id=" + "83adca921c699cc375407a61a4e90342"
                                  +"&redirect_uri=" + encodeURI("http://localhost:8080/redirect")
                                  +"&response_type=code&scope=account_email,friends,talk_message";      
      window.location.href = url;
    }
  }
}
</script>