<template>
  <HelloWorld />
</template>

<script>
import HelloWorld from '../components/HelloWorld';

export default {
  components: {
    HelloWorld,
  },
  mounted(){
    if(!this.$store.state.isLogin){
      this.$router.push("/login");
    }
  }
};
</script>
