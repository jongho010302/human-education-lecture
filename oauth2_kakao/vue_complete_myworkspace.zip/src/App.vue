<template>
  <v-app>
    <v-navigation-drawer v-model="drawer" app>
      <!-- -->
      <v-list>
        <v-subheader>Menus</v-subheader>
        <!-- list-item-group에 v-model이 선택된 메뉴 변수 0 1 2...-->
        <v-list-item-group v-model="selectedIndex" color="primary">
          <v-list-item v-for="(menu, i) in menus" :key="i" @click="navigateTo(menu.path)">
            <v-list-item-icon>
              <v-icon v-text="menu.icon"></v-icon>
            </v-list-item-icon>
            <v-list-item-content>
              <v-list-item-title v-text="menu.text"></v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list-item-group>
      </v-list>      
    </v-navigation-drawer>

    <v-app-bar color="deep-purple accent-4" dark app v-if="$store.state.isLogin" >
      <!-- -->
      <v-app-bar-nav-icon @click.stop="drawer = !drawer"></v-app-bar-nav-icon>
      <v-toolbar-title>My Workspace</v-toolbar-title>
    </v-app-bar>

    <!-- Sizes your content based upon application components -->
    <v-content>
      <!-- Provides the application the proper gutter -->
      <v-container fluid>
        <!-- If using vue-router -->
        <router-view></router-view>
      </v-container>
    </v-content>

    <v-footer app>
      <!-- -->
    </v-footer>
  </v-app>
</template>

<script>
export default {
  name: 'App',
  data: () => ({
    drawer:false,
    selectedIndex:0,
    menus: [
      /* https://cdn.materialdesignicons.com/4.1.95/ */
      { text: 'Home', icon: 'mdi-home', path:"/" },
      { text: 'Contacts', icon: 'mdi-contacts', path:"/contacts" },
      { text: 'Feeds', icon: 'mdi-forum', path:"/feeds" },
      { text: 'To-Do', icon: 'mdi-format-list-checks', path:"/todo" },
    ]
  }),
  methods: {
    navigateTo(path){
      /* https://router.vuejs.org/kr/guide/essentials/navigation.html */
      if(this.$route.path != path){
        this.$router.push(path);
      }
    }
  },
  watch:{
    $route (to){
      //console.log(to);
      this.menus.forEach((item, index)=>{
        if(item.path == to.path){
          this.selectedIndex = index;    
        }
      });
      
      console.log(this.$store.state.isLogin);
      console.log(this.$store.state.profile);
    }
  }   
};
</script>
