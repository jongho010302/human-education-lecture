module.exports = {
  plugins: {
    autoprefixer: {}
  }
}
