package com.kakao.controller;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;

import org.json.JSONObject;
import org.json.XML;

@RestController
public class KakaoController {
	//
		
	@RequestMapping(value="/profile", method=RequestMethod.GET)
	public Map<String, Object> getProfile(@RequestHeader("token") String token) throws Exception{
		System.out.println(token);
		URL url = new URL("https://kapi.kakao.com/v2/user/me"); 
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		
		con.setRequestMethod("GET"); 
		con.setRequestProperty("Authorization", "Bearer " + token);
		  
	    BufferedReader streamReader = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
	    
	    StringBuilder responseStrBuilder = new StringBuilder();
	    String inputStr;
	    while ((inputStr = streamReader.readLine()) != null)
	        responseStrBuilder.append(inputStr);

        JSONObject jsonObject = new JSONObject(responseStrBuilder.toString());
		
		// ��� �α�
		System.out.println(jsonObject.toString());
		
		return jsonObject.toMap();
	}

	@RequestMapping(value="/logout", method=RequestMethod.POST)
	public Map<String, Object> logout(@RequestHeader("token") String token) throws Exception{
		System.out.println(token);
		URL url = new URL("https://kapi.kakao.com/v1/user/logout"); 
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		
		con.setRequestMethod("POST"); 
		con.setRequestProperty("Authorization", "Bearer " + token);
		con.setDoOutput(true);
		  
	    BufferedReader streamReader = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
	    
	    StringBuilder responseStrBuilder = new StringBuilder();
	    String inputStr;
	    while ((inputStr = streamReader.readLine()) != null)
	        responseStrBuilder.append(inputStr);

        JSONObject jsonObject = new JSONObject(responseStrBuilder.toString());
		
		// ��� �α�
		System.out.println(jsonObject.toString());
		
		return jsonObject.toMap();
	}
	
	@RequestMapping(value="/friends", method=RequestMethod.GET)
	public Map<String, Object> getFriends(@RequestHeader("token") String token) throws Exception{
		System.out.println(token);
		URL url = new URL("https://kapi.kakao.com/v1/api/talk/friends"); 
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		
		con.setRequestMethod("GET"); 
		con.setRequestProperty("Authorization", "Bearer " + token);
		  
	    BufferedReader streamReader = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
	    
	    StringBuilder responseStrBuilder = new StringBuilder();
	    String inputStr;
	    while ((inputStr = streamReader.readLine()) != null)
	        responseStrBuilder.append(inputStr);

        JSONObject jsonObject = new JSONObject(responseStrBuilder.toString());
		
		// ��� �α�
		System.out.println(jsonObject.toString());
		
		return jsonObject.toMap();
	}
	
	@RequestMapping(value="/message", method=RequestMethod.POST)
	public Map<String, Object> sendMessage(@RequestHeader("token") String token, 
			 @RequestParam String template_object,  @RequestParam String uuids) throws Exception{
		System.out.println(token);
		URL url = new URL("https://kapi.kakao.com/v1/api/talk/friends/message/default/send"); 
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		
		con.setRequestMethod("POST"); 
		con.setRequestProperty("Authorization", "Bearer " + token);
		con.setDoOutput(true);
		
		String message = "receiver_uuids=" + uuids+"&template_object=" + template_object;
		System.out.print(message);
		
		try(OutputStream os = con.getOutputStream()) {
		    byte[] bytes = message.getBytes("utf-8");
		    os.write(bytes, 0, bytes.length);           
		}				
		  
	    BufferedReader streamReader = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
	    
	    StringBuilder responseStrBuilder = new StringBuilder();
	    String inputStr;
	    while ((inputStr = streamReader.readLine()) != null)
	        responseStrBuilder.append(inputStr);

        JSONObject jsonObject = new JSONObject(responseStrBuilder.toString());
		
		// ��� �α�
		System.out.println(jsonObject.toString());
		
		return jsonObject.toMap();
	}	

}
