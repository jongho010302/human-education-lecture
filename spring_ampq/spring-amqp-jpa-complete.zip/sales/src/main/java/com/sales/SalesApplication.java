package com.sales;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.sales.event.consumer.PurchaseOrderConsumer;

@SpringBootApplication
public class SalesApplication {

	@Autowired
	private PurchaseOrderConsumer consumer;
	
	public static void main(String[] args) {
		SpringApplication.run(SalesApplication.class, args);
	}
	
	@PostConstruct
	public void init() throws Exception {
		consumer.consume("create-order"); 
	}	
}
