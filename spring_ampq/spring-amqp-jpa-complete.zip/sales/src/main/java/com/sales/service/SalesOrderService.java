package com.sales.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import com.sales.entity.SalesOrderEntity;
import com.sales.entity.SalesOrderItemEntity;
import com.sales.event.model.PurchaseOrder;
import com.sales.event.model.PurchaseOrderItem;
import com.sales.repository.SalesOrderRepository;
import com.google.gson.Gson;
import com.sales.repository.SalesOrderItemRepository;

@Service
public class SalesOrderService {
	
	@Autowired
	SalesOrderRepository repo;
	
	@Autowired
	SalesOrderItemRepository itemRepo;
	
	public void processQueueMessage (String queueName, String message) {
		switch(queueName) {
			case "create-order":
				Gson gson = new Gson();
				PurchaseOrder e = gson.fromJson(message, PurchaseOrder.class);
				System.out.println("-- purchase_order --");
				System.out.println(e);
				save(e);
				break;
		}
	}

	// �θ� ���ڵ�� �ڽ� ���ڵ���� insert/update ó���� �ϳ��� Ʈ��������� ó���Ѵ�.
	// Ʈ�����: �������� ó�� ����
	// ����ó���� commit, ������ rollback
	@Transactional 
	public SalesOrderEntity save(PurchaseOrder e) {
		
		// save a parent		
		SalesOrderEntity salesOrder = repo.save(new SalesOrderEntity(e));
		
		// create children
		List<SalesOrderItemEntity> salesOrderItems  = new ArrayList<SalesOrderItemEntity>();
		for(PurchaseOrderItem purchaseOrderItem : e.getPurchaseOrderItems()) {
			salesOrderItems.add(new SalesOrderItemEntity(purchaseOrderItem, salesOrder.getId())); 
		}		
		
		// save children
		itemRepo.saveAll(salesOrderItems);
		
		return salesOrder;
	}
}
