package com.sales.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sales.entity.SalesOrderEntity;

public interface SalesOrderRepository extends JpaRepository<SalesOrderEntity, Integer> {

}
