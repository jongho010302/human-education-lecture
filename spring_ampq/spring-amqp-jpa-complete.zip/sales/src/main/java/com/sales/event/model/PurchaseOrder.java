package com.sales.event.model;

import java.util.List;
import com.sales.event.model.PurchaseOrderItem;

import lombok.Data;

@Data
public class PurchaseOrder {
	private int id;	
	private int amount;
	private String name;	
	private String address;		 
	private String status;
	private long timestamp;
    private List<PurchaseOrderItem> purchaseOrderItems;		
}
