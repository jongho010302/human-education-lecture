package com.sales.event.model;

import lombok.Data;

@Data
public class PurchaseOrderItem {

	private int id;
	private int purchaseOrderId; 
	private int productId; 
	private int unitPrice;
	private int quantity;
}
