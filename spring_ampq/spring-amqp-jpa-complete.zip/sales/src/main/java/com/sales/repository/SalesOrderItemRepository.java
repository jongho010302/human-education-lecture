package com.sales.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.sales.entity.SalesOrderItemEntity;

public interface SalesOrderItemRepository extends JpaRepository<SalesOrderItemEntity, Integer> {

}
