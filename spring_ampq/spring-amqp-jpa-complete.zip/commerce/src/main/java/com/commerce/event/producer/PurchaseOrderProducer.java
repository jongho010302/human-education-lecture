package com.commerce.event.producer;

import java.nio.charset.Charset;

import org.springframework.stereotype.Service;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

@Service
public class PurchaseOrderProducer {

	public static String AMQP_HOST = "ec2-15-164-212-224.ap-northeast-2.compute.amazonaws.com";
	public static String AMQP_USERNAME = "rabbitmq";
	public static String AMQP_PASSWORD = "password123";
	
	public void send(String queueName, String message) throws Exception {
		
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(AMQP_HOST);
		factory.setUsername(AMQP_USERNAME);
		factory.setPassword(AMQP_PASSWORD);
		
		Connection connection = factory.newConnection();
		Channel channel = connection.createChannel();
		
		channel.queueDeclare(queueName, false, false, false, null);
		channel.basicPublish("", queueName, null, message.getBytes(Charset.forName("UTF-8")));

        channel.close();
        connection.close();		
		
		System.out.println(" [x] Sent '" + message + "'");			
	}
}
