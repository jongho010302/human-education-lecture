package com.commerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.commerce.entity.PurchaseOrderEntity;
import com.commerce.repository.PurchaseOrderRepository;

import com.commerce.service.PurchaseOrderService;

@RestController
public class PurchaseOrderController {

	@Autowired
	PurchaseOrderRepository repo;
	
	@Autowired
	PurchaseOrderService service;	
			
	// ��� ��ȸ
	@RequestMapping(value="/purchase-orders", method=RequestMethod.GET)
	public List<PurchaseOrderEntity> getOrders() throws Exception{
		return repo.findAll(new Sort(Sort.Direction.DESC,"id"));
	}
	
	// �߰�
	@RequestMapping(value="/purchase-orders", method=RequestMethod.POST)
	public PurchaseOrderEntity setOrder(@RequestBody PurchaseOrderEntity e) throws Exception{
		System.out.println(e);
		return service.save(e);
	}
}
