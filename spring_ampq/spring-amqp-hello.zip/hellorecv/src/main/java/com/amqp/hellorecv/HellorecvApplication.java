package com.amqp.hellorecv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;


@SpringBootApplication
public class HellorecvApplication {

	private final static String QUEUE_NAME = "create-order";
	
	public static void main(String[] args) throws Exception {
		SpringApplication.run(HellorecvApplication.class, args);
		
		// ���� ���� ����
	    ConnectionFactory factory = new ConnectionFactory();
	    factory.setHost("ec2-15-164-212-224.ap-northeast-2.compute.amazonaws.com");
		factory.setUsername("rabbitmq"); 
		factory.setPassword("password123");
		
		// ���� ���� �� ä�� ����
	    Connection connection = factory.newConnection();
	    Channel channel = connection.createChannel();
	    
	    // ť ���� ����
	    channel.queueDeclare(QUEUE_NAME , false, false, false, null);
	    System.out.println(" [*] Waiting for messages. To exit press CTRL+C");
	    
	    // �޽����� �޾��� �� ó�����ִ� �޼ҵ� ����
	    DeliverCallback deliverCallback = (consumerTag, delivery) -> {
	        String message = new String(delivery.getBody(), "UTF-8");
	        System.out.println(" [x] Received '" + message + "'");
	    };	    
	    // ť ���� ���
	    channel.basicConsume(QUEUE_NAME, true, deliverCallback, consumerTag -> { });
		
	}

}
