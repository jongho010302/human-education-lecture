package com.amqp.hellosend;

import java.nio.charset.Charset;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.Channel;


@SpringBootApplication
public class HellosendApplication {

    // ������ ������ ����
    /*
    {
    	   "amount": 20000,
    	   "name": "ȫ�浿",
    	   "address": "�ߺδ�� 104",
    	   "status": "00",
    	   "timestamp": 1569210509000,
    	   "purchaseOrderItems":    [
	            {
	         "productId": 1,
	         "unitPrice": 10000,
	         "quantity": 1
	      	},
	            {
	         "productId": 2,
	         "unitPrice": 5000,
	         "quantity": 2
	      	}
	   ]
	}
	*/
	
	private final static String QUEUE_NAME = "create-order";
	private final static String MESSAGE = "{\"amount\":20000,\"name\":\"ȫ�浿\",\"address\":\"�ߺδ�� 104\",\"status\":\"00\",\"timestamp\":1569210509000,\"purchaseOrderItems\":[{\"productId\":1,\"unitPrice\":10000,\"quantity\":1},{\"productId\":2,\"unitPrice\":5000,\"quantity\":2}]}";
	
	public static void main(String[] args) throws Exception {
		SpringApplication.run(HellosendApplication.class, args);
		
		// ���� ���� ����
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost("ec2-15-164-212-224.ap-northeast-2.compute.amazonaws.com");
		factory.setUsername("rabbitmq");
		factory.setPassword("password123");
		
		// ���� ���� �� ä�� ����
	    Connection connection = factory.newConnection();
	    Channel channel = connection.createChannel();
	    
	    // ť ���� ����
	    channel.queueDeclare(QUEUE_NAME, false, false, false, null);
		
		// �޽��� ������
		channel.basicPublish("", QUEUE_NAME, null, MESSAGE.getBytes(Charset.forName("UTF-8")));
		System.out.println(" [x] Sent '" + MESSAGE + "'");	    
	}

}
